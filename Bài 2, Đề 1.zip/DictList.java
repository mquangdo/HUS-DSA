
@SuppressWarnings("unchecked")
public class DictList<T> implements ListInterface<T>{

	
	@Override
	public void add(T data) {
	    // TODO Auto-generated method stub
		
	}

	@Override
	public T get(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

}
