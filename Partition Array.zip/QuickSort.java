public class QuickSort{
    
    
    public int partition(int[] a)
    {
        return 0;
    }
    
    
    public static void main(String[] args)
    {
        QuickSort q = new QuickSort();
        
        int[] a = {1,2,5,3,4,1,3,4,5,6,10};
        
        int key = q.partition(a);
        
        System.out.println("key = "+a[key]+" index = "+key);
        System.out.print("Array a = ");
        for(int i = 0 ; i < a.length ; i++)
            System.out.print(a[i]+" ");
    }
    
}