import java.io.File;
import java.util.List;
@SuppressWarnings("unchecked")
public class Q2 {
	
	public static long size(File file) {
		
		return 0;
	}
	
	public static List<String> ls(File file) {
		
		
		return null;
	}


}
