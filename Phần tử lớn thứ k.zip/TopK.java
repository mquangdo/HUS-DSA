public class TopK{
    
    /*
        Hoàn thiện phương thức getTopk trả lại giá trị lớn thứ k trong dãy
        k <= a.length
    */
    public static int getTopk(int[] a, int k)
    {
        return 0;
    }
    
    
    public static void main(String[] args)
    {
        int[] a = {1, 3, 2, 1, 4, 5, 7, 9, 8, 5, 6};
        int k = 1;
        
        System.out.printf("Phần tử lớn thứ %d là: %d",k,getTopk(a,k));
        
    }
}