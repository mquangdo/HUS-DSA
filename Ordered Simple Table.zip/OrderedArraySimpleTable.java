

@SuppressWarnings("unchecked")

public class OrderedArraySimpleTable <Key extends Comparable<Key>, Value> implements OrderedSimpleTable<Key, Value> {

	private Key[]  keys;
	private Value[] values;
	int n = 0, default_size = 100;
	
	
	// Chú ý hoàn thiện hàm dựng, khởi tạo 2 mảng keys và values
	public  OrderedArraySimpleTable() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	//Phương thức thực hiện thêm 1 phần tử vào bảng tra cứu, phần tử mới được thêm vào sao
	// cho mảng keys luôn được sắp tăng dần
	public void put(Key key, Value value) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	//Phương thức thực hiện tìm kiếm khóa key trên mảng keys bằng thuật toán tìm kiếm nhị phân
	// kết quả trả về là chỉ số (index) của phần tử key trong mảng key
	// nếu không tìm thấy key trong mảng keys, trả lại -1
	public int binarySearch(Key key)
	{
		
		
		return -1;
	}
	
	
	// Phương thức get, lấy ra giá trị value tương ứng với key
	// Phương thức này gọi tới phương thức binarySearch(Key key)
	@Override
	public Value get(Key key) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	// xóa phần tử ra khỏi bảng tra cứu, dồn lại mảng sau khi xóa
	public void delete(Key key) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean contains(Key key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Iterable<Key> keys() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Key min() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Key max() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Key floor(Key key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Key ceiling(Key key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int rank(Key key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Key select(int k) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMax() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int size(Key u, Key v) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Iterable<Key> keys(Key u, Key v) {
		// TODO Auto-generated method stub
		return null;
	}

}
