import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Graph{
    
    
    
    public int[] djikstra(int[][] a, int x, int y)
    {
        int n = a.length;
        int[] dist = new int[n + 1];
        int[] prev = new int[n + 1];
        boolean[] visited = new boolean[n + 1];
        Arrays.fill(dist, Integer.MAX_VALUE);
        Arrays.fill(prev, -1); 
        dist[x] = 0;
        
        for(int i = 0; i < n; i++){
            int u = -1;
            for(int j = 0; j < n; j++){
                if(!visited[j] && (u == -1 || dist[j] < dist[u])){
                    u = j;
                }
            }
            if(dist[u] == Integer.MAX_VALUE){
                break;
            }
            visited[u] = true;
            for(int v = 0; v < n; v++){
                if(a[u][v] != 0 && !visited[v]){
                    int temp = dist[u] + a[u][v];
                    if(temp < dist[v]){
                        dist[v] = temp;
                        prev[v] = u;
                    }	 	  	    	   	      	   	   	        	 	
                }
            }
        }
        
        if(dist[y] == Integer.MAX_VALUE){
            return new int[]{0};
        }
        int[] path = new int[n + 1];
        int len = 0;
        
        for(int v = y; v != -1; v = prev[v]){
            path[len++] = v;
        }
        int[] res = new int[len];
        for(int i = 0; i < len; i++){
            res[i] = path[len - 1- i];
        }
        
        return res;
    }
    
   
}