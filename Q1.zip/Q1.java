public class Q1 {
    public static int max(double[] a, int n) {
        // 
        return -1;
    }
}