// Hoàn thành phương thức mergeArray thực hiện ghép 2 mảng a, b đã được sắp xếp thành 1 mảng đã được sắp xếp.

public class MergeArray{
    
    public int[] mergeArray(int[] a, int[] b)
    {
        
    }
    
    
}

