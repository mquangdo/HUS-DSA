public class Pattern{
    
    
    
    public int match(int[] a, int[] b)
    {
        return 0;
    }
    
    
}